﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OilGas.EventHubProvider
{
    public class PipeFlowTelemetryEvent : IEventHubMessage
    {
        public string ID { get; set; }
        public int SensorID { get; set; }
        public decimal MassFlow { get; set; }
        public decimal Temperature { get; set; }
        public decimal Humidity { get; set; }
        public DateTime CollectionTime { get; set; }
        public decimal Longitude { get; set; }
        public decimal Latitude { get; set; }

        public PipeFlowTelemetryEvent(string id, int sensorID, decimal massFlow, decimal temperature, decimal humidity, DateTime collectionTime, decimal Longitude, decimal Latitude)
        {
            this.ID = id;
            this.SensorID = sensorID;
            this.MassFlow = massFlow;
            this.Temperature = temperature;
            this.Humidity = humidity;
            this.CollectionTime = collectionTime;
            this.Longitude = Longitude;
            this.Latitude = Latitude;
        }
    }
}
